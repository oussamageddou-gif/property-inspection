import { useState, useRef } from "react";

const ROOMS = ["Living Room", "Kitchen", "Bedroom 1", "Bedroom 2", "Bathroom", "Hallway", "Garden", "Other"];
const CONDITIONS = ["Good", "Fair", "Poor"];
const ROOM_ITEMS = ["Overview", "Doors", "Ceiling", "Walls", "Flooring", "Windows", "Curtains/Blinds", "Furniture"];

const initialRoomData = () =>
  ROOM_ITEMS.reduce((acc, item) => ({ ...acc, [item]: { condition: "", photos: [] } }), {});

const initialForm = {
  propertyAddress: "", reportType: "", inspectionDate: "", inspectorName: "", tenantNumber: "",
  rooms: [],
  gasCertDate: "", eicrDate: "", smokeAlarm: "", smokeAlarmPhoto: [], coAlarm: "", fireExtinguisher: "",
  pestInfestation: "", pestNotes: "", isClean: "", dampness: "", dampnessPhoto: [], overallCondition: "",
  unauthorizedPets: "", damages: "", damagesPhotos: [], unauthorizedOccupants: "",
  electricityReading: "", electricityPhoto: [], gasReading: "", gasPhoto: [],
  waterReading: "", waterPhoto: [], keysReturned: "",
  generalNotes: "", inspectorSignature: [], tenantSignature: [],
};

const SECTIONS = [
  { id: 1, icon: "🏠", label: "Property" },
  { id: 2, icon: "🛏️", label: "Rooms" },
  { id: 3, icon: "✅", label: "Compliance" },
  { id: 4, icon: "🔍", label: "General" },
  { id: 5, icon: "⚠️", label: "Breaches" },
  { id: 6, icon: "🔌", label: "Meters" },
  { id: 7, icon: "📝", label: "Finish" },
];

function PhotoUpload({ label, value, onChange }) {
  const ref = useRef();
  const handleFiles = (e) => {
    const files = Array.from(e.target.files);
    Promise.all(files.map(f => new Promise(res => {
      const r = new FileReader();
      r.onload = ev => res({ name: f.name, url: ev.target.result });
      r.readAsDataURL(f);
    }))).then(imgs => onChange([...(value || []), ...imgs]));
  };
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ fontSize: 12, color: "#94a3b8", marginBottom: 6 }}>{label}</div>
      <div onClick={() => ref.current.click()} style={{
        border: "1.5px dashed #334155", borderRadius: 10, padding: "10px 16px",
        cursor: "pointer", display: "flex", alignItems: "center", gap: 10,
        background: "rgba(51,65,85,0.1)", transition: "all 0.2s",
      }}
        onMouseEnter={e => e.currentTarget.style.borderColor = "#f59e0b"}
        onMouseLeave={e => e.currentTarget.style.borderColor = "#334155"}>
        <span style={{ fontSize: 18 }}>📷</span>
        <span style={{ fontSize: 13, color: "#64748b" }}>
          {value?.length ? `${value.length} photo(s)` : "Upload photos"}
        </span>
        <input ref={ref} type="file" accept="image/*" multiple style={{ display: "none" }} onChange={handleFiles} />
      </div>
      {value?.length > 0 && (
        <div style={{ display: "flex", gap: 8, marginTop: 8, flexWrap: "wrap" }}>
          {value.map((img, i) => (
            <div key={i} style={{ position: "relative" }}>
              <img src={img.url} alt="" style={{ width: 56, height: 56, objectFit: "cover", borderRadius: 8 }} />
              <button onClick={() => onChange(value.filter((_, j) => j !== i))} style={{
                position: "absolute", top: -4, right: -4, background: "#ef4444", border: "none",
                borderRadius: "50%", width: 16, height: 16, cursor: "pointer", color: "#fff",
                fontSize: 9, lineHeight: "16px", padding: 0,
              }}>✕</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ChoiceGroup({ label, options, value, onChange }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ fontSize: 13, color: "#cbd5e1", marginBottom: 8 }}>{label}</div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {options.map(opt => (
          <button key={opt} onClick={() => onChange(opt === value ? "" : opt)} style={{
            padding: "7px 18px", borderRadius: 8, border: "1.5px solid",
            borderColor: value === opt ? "#f59e0b" : "#334155",
            background: value === opt ? "rgba(245,158,11,0.15)" : "rgba(15,23,42,0.5)",
            color: value === opt ? "#f59e0b" : "#64748b",
            cursor: "pointer", fontSize: 13, fontWeight: value === opt ? 600 : 400, transition: "all 0.18s",
          }}>{opt}</button>
        ))}
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div style={{ marginBottom: 14 }}>
      {label && <div style={{ fontSize: 13, color: "#cbd5e1", marginBottom: 6 }}>{label}</div>}
      {children}
    </div>
  );
}

const inputStyle = {
  width: "100%", padding: "10px 14px", borderRadius: 10,
  border: "1.5px solid #334155", background: "rgba(15,23,42,0.6)",
  color: "#e2e8f0", fontSize: 14, outline: "none", boxSizing: "border-box",
};

function generateReport(form) {
  const c = v => v === "Good" ? "#22c55e" : v === "Fair" ? "#f59e0b" : v === "Poor" ? "#ef4444" : "#94a3b8";
  const yn = v => v === "Yes" ? '<span style="color:#22c55e;font-weight:700">✓ Yes</span>' : v === "No" ? '<span style="color:#ef4444;font-weight:700">✗ No</span>' : "<span style='color:#94a3b8'>—</span>";

  const roomsHtml = form.rooms.map(room => `
    <div style="margin-bottom:28px;break-inside:avoid">
      <h3 style="background:#1e293b;color:#f59e0b;padding:10px 18px;border-radius:8px;margin:0 0 12px;font-size:15px">${room.name}</h3>
      <table style="width:100%;border-collapse:collapse;font-size:13px">
        ${ROOM_ITEMS.map(item => `
          <tr style="border-bottom:1px solid #f1f5f9">
            <td style="padding:8px 12px;color:#64748b;width:35%">${item}</td>
            <td style="padding:8px 12px;font-weight:700;color:${c(room[item]?.condition)}">${room[item]?.condition || "—"}</td>
            <td style="padding:8px 12px;color:#94a3b8">${room[item]?.photos?.length ? `📷 ${room[item].photos.length}` : ""}</td>
          </tr>`).join("")}
      </table>
      ${ROOM_ITEMS.filter(i => room[i]?.photos?.length).map(i =>
        `<div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap">
          ${room[i].photos.map(p => `<img src="${p.url}" style="width:90px;height:90px;object-fit:cover;border-radius:8px;border:1px solid #e2e8f0">`).join("")}
        </div>`).join("")}
    </div>`).join("");

  const html = `<!DOCTYPE html><html><head><meta charset="UTF-8">
  <title>Inspection Report - ${form.propertyAddress}</title>
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&display=swap" rel="stylesheet">
  <style>
    *{box-sizing:border-box;margin:0;padding:0}
    body{font-family:'Syne',sans-serif;background:#f8fafc;color:#1e293b;padding:32px}
    .header{background:linear-gradient(135deg,#0f172a,#1e293b);color:#fff;padding:28px 36px;border-radius:16px;margin-bottom:28px}
    .badge{background:#f59e0b;color:#0f172a;padding:3px 12px;border-radius:20px;font-size:12px;font-weight:700;display:inline-block;margin-top:6px}
    .section{background:#fff;border-radius:12px;border:1px solid #e2e8f0;margin-bottom:20px;overflow:hidden}
    .sh{background:#f8fafc;padding:12px 20px;font-weight:700;font-size:13px;color:#475569;border-bottom:1px solid #e2e8f0}
    .sb{padding:20px}
    .grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
    .fl{font-size:11px;color:#94a3b8;text-transform:uppercase;letter-spacing:0.05em;margin-bottom:3px}
    .fv{font-size:14px;font-weight:600;color:#1e293b}
    .sig{border:1px solid #e2e8f0;border-radius:8px;padding:16px;text-align:center;min-height:90px;display:flex;flex-direction:column;align-items:center;justify-content:center}
    @media print{body{padding:16px}.header{break-inside:avoid}}
  </style></head><body>
  <div class="header">
    <div style="font-size:11px;color:#94a3b8;letter-spacing:0.12em;margin-bottom:8px">PROPERTY INSPECTION REPORT</div>
    <div style="font-size:22px;font-weight:800;color:#f59e0b;margin-bottom:4px">${form.propertyAddress || "—"}</div>
    <div class="badge">${form.reportType || "Report"}</div>
    <div style="display:flex;gap:24px;margin-top:14px;font-size:13px;color:#94a3b8">
      <span>📅 ${form.inspectionDate || "—"}</span>
      <span>👤 ${form.inspectorName || "—"}</span>
      <span>📞 ${form.tenantNumber || "—"}</span>
    </div>
  </div>

  ${form.rooms.length ? `<div class="section"><div class="sh">🛏️ Room Inspection</div><div class="sb">${roomsHtml}</div></div>` : ""}

  <div class="section"><div class="sh">✅ Compliance & Safety</div><div class="sb"><div class="grid">
    <div><div class="fl">Gas Safety Certificate</div><div class="fv">${form.gasCertDate || "—"}</div></div>
    <div><div class="fl">EICR Date</div><div class="fv">${form.eicrDate || "—"}</div></div>
    <div><div class="fl">Smoke Alarm</div><div class="fv">${yn(form.smokeAlarm)}</div></div>
    <div><div class="fl">CO Alarm</div><div class="fv">${yn(form.coAlarm)}</div></div>
    <div><div class="fl">Fire Extinguisher</div><div class="fv">${yn(form.fireExtinguisher)}</div></div>
  </div></div></div>

  <div class="section"><div class="sh">🏠 General Condition</div><div class="sb"><div class="grid">
    <div><div class="fl">Pest Infestation</div><div class="fv">${yn(form.pestInfestation)}</div></div>
    <div><div class="fl">Property Clean</div><div class="fv">${yn(form.isClean)}</div></div>
    <div><div class="fl">Dampness/Mold</div><div class="fv">${yn(form.dampness)}</div></div>
    <div><div class="fl">Overall Condition</div><div class="fv">${form.overallCondition ? form.overallCondition + "/5" : "—"}</div></div>
  </div>${form.pestNotes ? `<div style="margin-top:12px"><div class="fl">Pest Notes</div><div class="fv">${form.pestNotes}</div></div>` : ""}</div></div>

  <div class="section"><div class="sh">⚠️ Tenancy Breaches</div><div class="sb"><div class="grid">
    <div><div class="fl">Unauthorized Pets</div><div class="fv">${yn(form.unauthorizedPets)}</div></div>
    <div><div class="fl">Damages Beyond Wear</div><div class="fv">${yn(form.damages)}</div></div>
    <div><div class="fl">Unauthorized Occupants</div><div class="fv">${yn(form.unauthorizedOccupants)}</div></div>
  </div></div></div>

  <div class="section"><div class="sh">🔌 Meters & Keys</div><div class="sb"><div class="grid">
    <div><div class="fl">Electricity</div><div class="fv">${form.electricityReading || "—"}</div></div>
    <div><div class="fl">Gas</div><div class="fv">${form.gasReading || "—"}</div></div>
    <div><div class="fl">Water</div><div class="fv">${form.waterReading || "—"}</div></div>
    <div><div class="fl">Keys Returned</div><div class="fv">${form.keysReturned || "—"}</div></div>
  </div></div></div>

  ${form.generalNotes ? `<div class="section"><div class="sh">📝 General Notes</div><div class="sb"><p style="color:#475569;line-height:1.7">${form.generalNotes}</p></div></div>` : ""}

  <div class="section"><div class="sh">✍️ Signatures</div><div class="sb"><div class="grid">
    <div class="sig">${form.inspectorSignature?.[0] ? `<img src="${form.inspectorSignature[0].url}" style="max-height:70px;max-width:100%">` : '<div style="color:#94a3b8;font-size:12px">Inspector Signature</div>'}
      <div style="font-size:11px;color:#94a3b8;margin-top:8px">${form.inspectorName || "Inspector"}</div></div>
    <div class="sig">${form.tenantSignature?.[0] ? `<img src="${form.tenantSignature[0].url}" style="max-height:70px;max-width:100%">` : '<div style="color:#94a3b8;font-size:12px">Tenant Signature</div>'}
      <div style="font-size:11px;color:#94a3b8;margin-top:8px">Tenant</div></div>
  </div></div></div>

  <div style="text-align:center;color:#94a3b8;font-size:11px;margin-top:24px;padding-top:16px;border-top:1px solid #e2e8f0">
    Generated ${new Date().toLocaleString()} · Property Inspection System
  </div></body></html>`;

  const blob = new Blob([html], { type: "text/html" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `Inspection_${(form.propertyAddress || "report").replace(/\s+/g, "_")}_${form.inspectionDate || new Date().toISOString().slice(0,10)}.html`;
  a.click();
  URL.revokeObjectURL(url);
}

export default function App() {
  const [form, setForm] = useState(initialForm);
  const [section, setSection] = useState(1);
  const [editingRoom, setEditingRoom] = useState(null);
  const [newRoomName, setNewRoomName] = useState("");
  const [downloaded, setDownloaded] = useState(false);

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

  const addRoom = () => {
    if (!newRoomName) return;
    setForm(f => ({ ...f, rooms: [...f.rooms, { name: newRoomName, ...initialRoomData() }] }));
    setEditingRoom(form.rooms.length);
    setNewRoomName("");
  };

  const updateRoom = (idx, item, field, val) => {
    setForm(f => {
      const rooms = [...f.rooms];
      rooms[idx] = { ...rooms[idx], [item]: { ...rooms[idx][item], [field]: val } };
      return { ...f, rooms };
    });
  };

  const pct = () => {
    const req = [form.propertyAddress, form.reportType, form.inspectionDate, form.inspectorName, form.smokeAlarm, form.overallCondition];
    return Math.round(req.filter(Boolean).length / req.length * 100);
  };

  const card = {
    background: "rgba(15,23,42,0.7)", borderRadius: 16, border: "1px solid #1e293b",
    padding: 22, marginBottom: 16, backdropFilter: "blur(12px)",
  };

  return (
    <>
      <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&display=swap" rel="stylesheet" />
      <div style={{ minHeight: "100vh", background: "#060d1a", backgroundImage: "radial-gradient(ellipse at 20% 20%,rgba(245,158,11,0.05) 0%,transparent 60%),radial-gradient(ellipse at 80% 80%,rgba(59,130,246,0.04) 0%,transparent 60%)", fontFamily: "Syne,sans-serif", color: "#e2e8f0", paddingBottom: 80 }}>

        {/* Header */}
        <div style={{ background: "rgba(15,23,42,0.95)", borderBottom: "1px solid #1e293b", padding: "14px 20px", position: "sticky", top: 0, zIndex: 100, backdropFilter: "blur(20px)" }}>
          <div style={{ maxWidth: 620, margin: "0 auto" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
              <div>
                <div style={{ fontSize: 10, color: "#f59e0b", letterSpacing: "0.15em", fontWeight: 700 }}>PROPERTY INSPECTION</div>
                <div style={{ fontSize: 13, color: "#64748b", marginTop: 2 }}>{form.propertyAddress || "New Report"}</div>
              </div>
              <div style={{ background: "rgba(245,158,11,0.1)", border: "1px solid rgba(245,158,11,0.25)", borderRadius: 20, padding: "4px 14px", fontSize: 13, color: "#f59e0b", fontWeight: 700 }}>{pct()}%</div>
            </div>
            <div style={{ height: 3, background: "#1e293b", borderRadius: 4 }}>
              <div style={{ height: "100%", background: "linear-gradient(90deg,#f59e0b,#fbbf24)", borderRadius: 4, width: `${pct()}%`, transition: "width 0.4s" }} />
            </div>
          </div>
        </div>

        {/* Nav */}
        <div style={{ maxWidth: 620, margin: "0 auto", padding: "14px 20px 0" }}>
          <div style={{ display: "flex", gap: 6, overflowX: "auto", paddingBottom: 4 }}>
            {SECTIONS.map(s => (
              <button key={s.id} onClick={() => setSection(s.id)} style={{
                padding: "7px 13px", borderRadius: 20, border: "1.5px solid",
                borderColor: section === s.id ? "#f59e0b" : "#1e293b",
                background: section === s.id ? "rgba(245,158,11,0.12)" : "transparent",
                color: section === s.id ? "#f59e0b" : "#475569",
                cursor: "pointer", fontSize: 12, fontWeight: 600, whiteSpace: "nowrap", transition: "all 0.18s",
              }}>{s.icon} {s.label}</button>
            ))}
          </div>
        </div>

        {/* Sections */}
        <div style={{ maxWidth: 620, margin: "14px auto 0", padding: "0 20px" }}>

          {section === 1 && (
            <div style={card}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
                <span style={{ fontSize: 20 }}>🏠</span>
                <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: "#f1f5f9" }}>Property Information</h2>
              </div>
              <Field label="Property Address">
                <input value={form.propertyAddress} onChange={e => set("propertyAddress", e.target.value)} placeholder="e.g. 123 Main Street, London" style={inputStyle} />
              </Field>
              <Field label="Report Type">
                <select value={form.reportType} onChange={e => set("reportType", e.target.value)} style={{ ...inputStyle, cursor: "pointer" }}>
                  <option value="">— Select —</option>
                  {["Check-In", "Check-Out", "Mid-Term", "Routine"].map(o => <option key={o}>{o}</option>)}
                </select>
              </Field>
              <Field label="Inspection Date">
                <input type="date" value={form.inspectionDate} onChange={e => set("inspectionDate", e.target.value)} style={inputStyle} />
              </Field>
              <Field label="Inspector Name">
                <input value={form.inspectorName} onChange={e => set("inspectorName", e.target.value)} placeholder="Full name" style={inputStyle} />
              </Field>
              <Field label="Tenant Number">
                <input value={form.tenantNumber} onChange={e => set("tenantNumber", e.target.value)} placeholder="Phone number" style={inputStyle} />
              </Field>
            </div>
          )}

          {section === 2 && (
            <>
              <div style={card}>
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
                  <span style={{ fontSize: 20 }}>➕</span>
                  <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: "#f1f5f9" }}>Add Room</h2>
                </div>
                <div style={{ display: "flex", gap: 10 }}>
                  <select value={newRoomName} onChange={e => setNewRoomName(e.target.value)} style={{ flex: 1, ...inputStyle, cursor: "pointer" }}>
                    <option value="">Select Room Type</option>
                    {ROOMS.map(r => <option key={r}>{r}</option>)}
                  </select>
                  <button onClick={addRoom} style={{ background: "#f59e0b", border: "none", borderRadius: 10, padding: "10px 20px", color: "#0f172a", fontWeight: 700, fontSize: 14, cursor: "pointer" }}>Add</button>
                </div>
              </div>

              {form.rooms.length === 0 && (
                <div style={{ textAlign: "center", color: "#334155", padding: "36px 0", fontSize: 14 }}>No rooms added yet.</div>
              )}

              {form.rooms.map((room, idx) => (
                <div key={idx} style={{ marginBottom: 10 }}>
                  <button onClick={() => setEditingRoom(editingRoom === idx ? null : idx)} style={{
                    width: "100%", padding: "13px 18px", borderRadius: editingRoom === idx ? "12px 12px 0 0" : 12,
                    border: "1.5px solid", borderColor: editingRoom === idx ? "#f59e0b" : "#1e293b",
                    background: editingRoom === idx ? "rgba(245,158,11,0.08)" : "rgba(15,23,42,0.7)",
                    color: "#e2e8f0", cursor: "pointer", display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 14, fontWeight: 600,
                  }}>
                    <span>🛏️ {room.name}</span>
                    <span style={{ color: "#64748b", fontSize: 12 }}>{ROOM_ITEMS.filter(i => room[i]?.condition).length}/{ROOM_ITEMS.length} {editingRoom === idx ? "▲" : "▼"}</span>
                  </button>
                  {editingRoom === idx && (
                    <div style={{ background: "rgba(15,23,42,0.7)", border: "1.5px solid #f59e0b", borderTop: "none", borderRadius: "0 0 12px 12px", padding: 20 }}>
                      {ROOM_ITEMS.map(item => (
                        <div key={item} style={{ marginBottom: 16, paddingBottom: 16, borderBottom: "1px solid #0f172a" }}>
                          <ChoiceGroup label={`${item} Condition`} options={CONDITIONS} value={room[item]?.condition || ""} onChange={v => updateRoom(idx, item, "condition", v)} />
                          <PhotoUpload label={`${item} Photos`} value={room[item]?.photos || []} onChange={v => updateRoom(idx, item, "photos", v)} />
                        </div>
                      ))}
                      <button onClick={() => { setForm(f => ({ ...f, rooms: f.rooms.filter((_, i) => i !== idx) })); setEditingRoom(null); }}
                        style={{ background: "rgba(239,68,68,0.1)", border: "1px solid #ef4444", color: "#ef4444", borderRadius: 8, padding: "8px 16px", cursor: "pointer", fontSize: 13 }}>
                        🗑 Remove Room
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </>
          )}

          {section === 3 && (
            <div style={card}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
                <span style={{ fontSize: 20 }}>✅</span>
                <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: "#f1f5f9" }}>Compliance & Safety</h2>
              </div>
              <Field label="Gas Safety Certificate Date"><input type="date" value={form.gasCertDate} onChange={e => set("gasCertDate", e.target.value)} style={inputStyle} /></Field>
              <Field label="EICR Date"><input type="date" value={form.eicrDate} onChange={e => set("eicrDate", e.target.value)} style={inputStyle} /></Field>
              <ChoiceGroup label="Is the smoke alarm working?" options={["Yes", "No"]} value={form.smokeAlarm} onChange={v => set("smokeAlarm", v)} />
              <PhotoUpload label="Smoke Alarm Photo" value={form.smokeAlarmPhoto} onChange={v => set("smokeAlarmPhoto", v)} />
              <ChoiceGroup label="Is the carbon monoxide alarm working?" options={["Yes", "No"]} value={form.coAlarm} onChange={v => set("coAlarm", v)} />
              <ChoiceGroup label="Is the fire extinguisher present?" options={["Yes", "No"]} value={form.fireExtinguisher} onChange={v => set("fireExtinguisher", v)} />
            </div>
          )}

          {section === 4 && (
            <div style={card}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
                <span style={{ fontSize: 20 }}>🔍</span>
                <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: "#f1f5f9" }}>General Property Condition</h2>
              </div>
              <ChoiceGroup label="Is there any pest infestation or insects?" options={["Yes", "No"]} value={form.pestInfestation} onChange={v => set("pestInfestation", v)} />
              {form.pestInfestation === "Yes" && <Field label="Pest Notes"><input value={form.pestNotes} onChange={e => set("pestNotes", e.target.value)} placeholder="Describe..." style={inputStyle} /></Field>}
              <ChoiceGroup label="Is the property clean?" options={["Yes", "No"]} value={form.isClean} onChange={v => set("isClean", v)} />
              <ChoiceGroup label="Is there any dampness or mold?" options={["Yes", "No"]} value={form.dampness} onChange={v => set("dampness", v)} />
              {form.dampness === "Yes" && <PhotoUpload label="Dampness/Mold Photo" value={form.dampnessPhoto} onChange={v => set("dampnessPhoto", v)} />}
              <ChoiceGroup label="Overall property condition (1–5)" options={["1","2","3","4","5"]} value={form.overallCondition} onChange={v => set("overallCondition", v)} />
            </div>
          )}

          {section === 5 && (
            <div style={card}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
                <span style={{ fontSize: 20 }}>⚠️</span>
                <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: "#f1f5f9" }}>Tenancy Breaches</h2>
              </div>
              <ChoiceGroup label="Are there any unauthorized pets?" options={["Yes","No"]} value={form.unauthorizedPets} onChange={v => set("unauthorizedPets", v)} />
              <ChoiceGroup label="Are there any damages beyond normal wear and tear?" options={["Yes","No"]} value={form.damages} onChange={v => set("damages", v)} />
              {form.damages === "Yes" && <PhotoUpload label="Damages Photos" value={form.damagesPhotos} onChange={v => set("damagesPhotos", v)} />}
              <ChoiceGroup label="Are there any unauthorized occupants?" options={["Yes","No"]} value={form.unauthorizedOccupants} onChange={v => set("unauthorizedOccupants", v)} />
            </div>
          )}

          {section === 6 && (
            <div style={card}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
                <span style={{ fontSize: 20 }}>🔌</span>
                <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: "#f1f5f9" }}>Meters & Keys</h2>
              </div>
              <Field label="Electricity Meter Reading"><input value={form.electricityReading} onChange={e => set("electricityReading", e.target.value)} placeholder="kWh" style={inputStyle} /></Field>
              <PhotoUpload label="Electricity Meter Photo" value={form.electricityPhoto} onChange={v => set("electricityPhoto", v)} />
              <Field label="Gas Meter Reading"><input value={form.gasReading} onChange={e => set("gasReading", e.target.value)} placeholder="m³" style={inputStyle} /></Field>
              <PhotoUpload label="Gas Meter Photo" value={form.gasPhoto} onChange={v => set("gasPhoto", v)} />
              <Field label="Water Meter Reading"><input value={form.waterReading} onChange={e => set("waterReading", e.target.value)} placeholder="m³" style={inputStyle} /></Field>
              <PhotoUpload label="Water Meter Photo" value={form.waterPhoto} onChange={v => set("waterPhoto", v)} />
              <Field label="Number of Keys Returned"><input value={form.keysReturned} onChange={e => set("keysReturned", e.target.value)} placeholder="e.g. 2" style={inputStyle} /></Field>
            </div>
          )}

          {section === 7 && (
            <div style={card}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
                <span style={{ fontSize: 20 }}>📝</span>
                <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: "#f1f5f9" }}>Final Notes & Signatures</h2>
              </div>
              <Field label="General Notes">
                <textarea rows={4} value={form.generalNotes} onChange={e => set("generalNotes", e.target.value)} placeholder="Any additional observations..." style={{ ...inputStyle, resize: "vertical" }} />
              </Field>
              <PhotoUpload label="Inspector Signature" value={form.inspectorSignature} onChange={v => set("inspectorSignature", v)} />
              <PhotoUpload label="Tenant Signature" value={form.tenantSignature} onChange={v => set("tenantSignature", v)} />

              <div style={{ marginTop: 24, padding: 18, background: "rgba(245,158,11,0.06)", border: "1px solid rgba(245,158,11,0.2)", borderRadius: 12 }}>
                <div style={{ fontSize: 13, color: "#94a3b8", marginBottom: 14 }}>
                  {form.rooms.length} room(s) · {pct()}% complete
                </div>
                <button onClick={() => { generateReport(form); setDownloaded(true); setTimeout(() => setDownloaded(false), 3000); }} style={{
                  width: "100%", padding: 14, borderRadius: 12, border: "none",
                  background: "linear-gradient(135deg,#f59e0b,#fbbf24)", color: "#0f172a",
                  fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: 15, cursor: "pointer",
                  boxShadow: "0 4px 20px rgba(245,158,11,0.3)",
                }}>
                  ⬇️ Download Report
                </button>
                {downloaded && <div style={{ marginTop: 10, textAlign: "center", color: "#22c55e", fontSize: 13 }}>✅ Downloaded! Open the HTML file in your browser to print as PDF.</div>}
              </div>
            </div>
          )}

          {/* Bottom Nav */}
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8 }}>
            {section > 1
              ? <button onClick={() => setSection(s => s - 1)} style={{ padding: "11px 22px", borderRadius: 10, border: "1.5px solid #334155", background: "transparent", color: "#94a3b8", cursor: "pointer", fontSize: 14 }}>← Back</button>
              : <div />}
            {section < 7 && (
              <button onClick={() => setSection(s => s + 1)} style={{ padding: "11px 26px", borderRadius: 10, border: "none", background: "linear-gradient(135deg,#f59e0b,#fbbf24)", color: "#0f172a", fontWeight: 700, fontSize: 14, cursor: "pointer" }}>Next →</button>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
